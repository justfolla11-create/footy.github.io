// Initialize Video Player
const player = videojs('football-player', {
    autoplay: false,
    controls: true,
    responsive: true,
    fluid: true
});

// Register Service Worker for Offline Assets & Mobile/Desktop App Installability
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('Service Worker successfully registered:', registration.scope);
            })
            .catch(error => {
                console.error('Service Worker registration failed:', error);
            });
    });
}